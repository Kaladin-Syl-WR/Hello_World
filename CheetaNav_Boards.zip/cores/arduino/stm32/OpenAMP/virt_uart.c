#ifdef VIRTIOCON

#include "virtio_config.h"
#include "virtual_driver/virt_uart.c"

#endif /* VIRTIOCON */
