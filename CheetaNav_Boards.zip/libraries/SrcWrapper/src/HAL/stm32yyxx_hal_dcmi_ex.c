#ifdef STM32F2xx
  #include "stm32f2xx_hal_dcmi_ex.c"
#endif
#ifdef STM32F4xx
  #include "stm32f4xx_hal_dcmi_ex.c"
#endif
#ifdef STM32F7xx
  #include "stm32f7xx_hal_dcmi_ex.c"
#endif
